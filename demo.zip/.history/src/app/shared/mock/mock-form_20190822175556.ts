import { FormData } from './../interface/form-data';

export const MockForm: FormData[] = [
  {
    controlName: 'Username',
    controlType: 'text',
    valueType: 'text',
    class: 'col-',
    id: 'username',
    currentValue: 'asdasdasd',
    placeholder: 'Enter username',
    validators: {
      required: true,
      minlength: 5
    }
  },
  {
    controlName: 'Telephone',
    placeholder: 'Enter Phone',
    valueType: 'tel',
    id: 'tel',
    controlType: 'text',
    currentValue: 'atel',
    validators: {
      required: true,
      minlength: 7,
      maxlength: 10
    }
  }
];
