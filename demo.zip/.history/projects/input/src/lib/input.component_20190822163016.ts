import { Component, OnInit, Input, Output, EventEmitter } from '@angular/core';

@Component({
  selector: 'ui-input',
  template: `
  <input type='text' [value]='inputValue' [name]='inputName' [disabled]='inputDisabled' (click)="click()">
  `,
  styles: []
})
export class InputComponent implements OnInit {
  @Input() inputValue: string;
  @Input() inputName: string;
  @Output() clickHandler: EventEmitter<any> = new EventEmitter<any>();
  @Input() inputDisabled: boolean;
  constructor() { }

  ngOnInit() {
  }
  clickHandler() {
    this.triggerRatingSelection.emit(this.inputValue);
  }
}
