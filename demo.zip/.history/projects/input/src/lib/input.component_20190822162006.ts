import { Component, OnInit, Input, Output, EventEmitter } from '@angular/core';

@Component({
  selector: 'ui-input',
  template: `
  <input type='text' [value]='inputValue' [name]='inputName' [disabled]='inputDisabled' >
  `,
  styles: []
})
export class InputComponent implements OnInit {
  @Input() inputValue: string;
  @Input() inputName: string;
  @Output('clickHandler') clickHandler = new EventEmitter<string>()
  @Input() inputDisabled: boolean;
  constructor() { }

  ngOnInit() {
  }

}
