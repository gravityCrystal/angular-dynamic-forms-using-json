import { Component, OnInit, Input, Output, EventEmitter } from '@angular/core';

@Component({
  selector: 'ui-input',
  template: `
  <input type='text' [value]='inputValue' [name]='inputName' [disabled]='inputDisabled' (blur)="clickFunc()">
  `,
  styles: []
})
export class InputComponent implements OnInit {
  @Input() inputName: string;
  @Output() clickHandler: EventEmitter<any> = new EventEmitter<any>();
  @Input() inputDisabled: boolean;
  constructor() { }

  ngOnInit() {
  }
  clickFunc() {
    this.clickHandler.emit(this.inputValue);
  }
}
