import { Component, OnInit, Input, Output, EventEmitter } from '@angular/core';

@Component({
  selector: 'ui-input',
  template: `
  <input type='text' [value]='value' [name]='name' [disabled]='disabled' (click)="clickHandler()">
  `,
  styles: []
})
export class InputComponent implements OnInit {
  @Input() value: string;
  @Input() name: string;
  @Output('clickHandler') clickHandler = new EventEmitter<string>()
  @Input() disabled: boolean;
  constructor() { }

  ngOnInit() {
  }

}
